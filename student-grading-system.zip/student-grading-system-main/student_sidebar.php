<section>
        <header class="header">
        	<a href="studenthome.php">Student Dashboard</a>
        <div class="logout">
        	<a href="logout.php" class="btn">logout</a>
        </div>
        </header>
</section>
        <aside>
        	<ul>
        		<li>
        			<a class="btn" href="student_profile.php">My Profile</a>
        		</li>
        		<li>
        			<a class="btn" href="view_result.php">View Result</a>
        		</li>
        		<li>
        			<a class="btn" href="assignment_response.php">Assignment</a>
        		</li>
        		<li>
        			<a class="btn" href="stu_view_teacher.php">View Teacher</a>
        		</li>
        	</ul>
        </aside>