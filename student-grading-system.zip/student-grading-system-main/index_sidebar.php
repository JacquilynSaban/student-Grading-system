<header class="header">
                <a href="index.php">Student Grading System</a>
</header>
        <aside>
        	<ul>
        		<li>
        			<a class="btn" href="login.php">Admin Login</a>
        		</li>
        		<li>
        			<a class="btn" href="student_login.php">Student Login</a>
        		</li>
        		<li>
        			<a class="btn" href="teacher_login.php">Teacher Login</a>
        		</li>
                        <li>
                                <a class="btn" href="index.php">GoTo Homepage</a>
                        </li>
        	</ul>
        </aside>