<section>
<header class="header">
                <a link="black" vlink="black" alink="black" href="adminhome.php">Admin Dashboard</a>
        <div class="logout">
                <a link="black" vlink="black" alink="black" href="logout.php" class="btn">logout</a>
        </div>
</header>
</section>
        <aside>
        	<ul>
        		<li>
        			<a class="btn" href="add_student.php">Add Student</a>
        		</li>
        		<li>
        			<a class="btn" href="view_student.php">Student List</a>
        		</li>
        		<li>
        			<a class="btn" href="add_teacher.php">Add Teacher</a>
        		</li>
        		<li>
        			<a class="btn" href="view_teacher.php">Teacher List</a>
        		</li>
                        <li>
                                <a class="btn" href="admin_view_result.php">View Result</a>
                        </li>
                        <li>
                                <a class="btn" href="feedback.php">View Feedback</a>
                        </li>
        	</ul>
        </aside>