<section>
<header class="header">
        	<a href="teacherhome.php">Teacher Dashboard</a>
        <div class="logout">
        	<a href="logout.php" class="btn">logout</a>
        </div>
        </header>
</section>
        <aside>
        	<ul>
        		<li>
        			<a class="btn" href="teacher_profile.php">My Profile</a>
        		</li>
        		<li>
        			<a class="btn" href="add_exam.php">Add Exam</a>
        		</li>
                        <li>
                                <a class="btn" href="add_result.php">Add Result</a>
                        </li>
        		<li>
        			<a class="btn" href="add_assignment.php">Add Assignment</a>
        		</li>
                        <li>
                                <a class="btn" href="assign_response.php">View Assignment</a>
                        </li>
                        <li>
        			<a class="btn" href="user_view_student.php">Students List</a>
        		</li>
        		<li>
        			<a class="btn" href="user_view_teacher.php">Teacher List</a>
        		</li>
        	</ul>
        </aside>